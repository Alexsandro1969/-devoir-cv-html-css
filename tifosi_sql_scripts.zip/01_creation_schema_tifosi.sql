-- =========================================================
-- Projet Tifosi - Script 1
-- Création de la base de données et du schéma MySQL
-- =========================================================

DROP DATABASE IF EXISTS tifosi;
CREATE DATABASE tifosi
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- Création de l'utilisateur applicatif
CREATE USER IF NOT EXISTS 'tifosi'@'localhost' IDENTIFIED BY 'Tifosi_2025!';
GRANT ALL PRIVILEGES ON tifosi.* TO 'tifosi'@'localhost';
FLUSH PRIVILEGES;

USE tifosi;

-- =========================================================
-- Tables de référence
-- =========================================================

CREATE TABLE ingredient (
    id_ingredient INT NOT NULL,
    nom VARCHAR(100) NOT NULL,
    PRIMARY KEY (id_ingredient),
    UNIQUE KEY uq_ingredient_nom (nom)
) ENGINE=InnoDB;

CREATE TABLE marque (
    id_marque INT NOT NULL,
    nom VARCHAR(100) NOT NULL,
    PRIMARY KEY (id_marque),
    UNIQUE KEY uq_marque_nom (nom)
) ENGINE=InnoDB;

CREATE TABLE focaccia (
    id_focaccia INT NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prix DECIMAL(5,2) NOT NULL,
    PRIMARY KEY (id_focaccia),
    UNIQUE KEY uq_focaccia_nom (nom),
    CONSTRAINT chk_focaccia_prix CHECK (prix > 0)
) ENGINE=InnoDB;

CREATE TABLE boisson (
    id_boisson INT NOT NULL,
    nom VARCHAR(150) NOT NULL,
    id_marque INT NOT NULL,
    PRIMARY KEY (id_boisson),
    UNIQUE KEY uq_boisson_nom (nom),
    KEY idx_boisson_marque (id_marque),
    CONSTRAINT fk_boisson_marque
        FOREIGN KEY (id_marque) REFERENCES marque (id_marque)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================================================
-- Tables métier du MCD fourni dans le brief
-- =========================================================

CREATE TABLE client (
    id_client INT NOT NULL AUTO_INCREMENT,
    nom VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL,
    code_postal VARCHAR(10) NOT NULL,
    PRIMARY KEY (id_client),
    UNIQUE KEY uq_client_email (email)
) ENGINE=InnoDB;

CREATE TABLE menu (
    id_menu INT NOT NULL AUTO_INCREMENT,
    nom VARCHAR(120) NOT NULL,
    prix DECIMAL(5,2) NOT NULL,
    PRIMARY KEY (id_menu),
    UNIQUE KEY uq_menu_nom (nom),
    CONSTRAINT chk_menu_prix CHECK (prix > 0)
) ENGINE=InnoDB;

CREATE TABLE comprend (
    id_focaccia INT NOT NULL,
    id_ingredient INT NOT NULL,
    quantite INT NOT NULL,
    PRIMARY KEY (id_focaccia, id_ingredient),
    KEY idx_comprend_ingredient (id_ingredient),
    CONSTRAINT chk_comprend_quantite CHECK (quantite > 0),
    CONSTRAINT fk_comprend_focaccia
        FOREIGN KEY (id_focaccia) REFERENCES focaccia (id_focaccia)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_comprend_ingredient
        FOREIGN KEY (id_ingredient) REFERENCES ingredient (id_ingredient)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE contient (
    id_menu INT NOT NULL,
    id_boisson INT NOT NULL,
    PRIMARY KEY (id_menu, id_boisson),
    KEY idx_contient_boisson (id_boisson),
    CONSTRAINT fk_contient_menu
        FOREIGN KEY (id_menu) REFERENCES menu (id_menu)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_contient_boisson
        FOREIGN KEY (id_boisson) REFERENCES boisson (id_boisson)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE est_constitue (
    id_menu INT NOT NULL,
    id_focaccia INT NOT NULL,
    PRIMARY KEY (id_menu, id_focaccia),
    KEY idx_est_constitue_focaccia (id_focaccia),
    CONSTRAINT fk_est_constitue_menu
        FOREIGN KEY (id_menu) REFERENCES menu (id_menu)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_est_constitue_focaccia
        FOREIGN KEY (id_focaccia) REFERENCES focaccia (id_focaccia)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE achete (
    id_client INT NOT NULL,
    id_menu INT NOT NULL,
    date_achat DATETIME NOT NULL,
    PRIMARY KEY (id_client, id_menu, date_achat),
    KEY idx_achete_menu (id_menu),
    CONSTRAINT fk_achete_client
        FOREIGN KEY (id_client) REFERENCES client (id_client)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_achete_menu
        FOREIGN KEY (id_menu) REFERENCES menu (id_menu)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;
