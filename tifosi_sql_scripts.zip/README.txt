# Projet Tifosi - Scripts SQL

Ordre d'exécution recommandé dans MySQL :

1. `01_creation_schema_tifosi.sql`
2. `02_insertion_donnees_tifosi.sql`
3. `03_requetes_test_tifosi.sql`

## Remarque importante
Les fichiers Excel fournis contiennent une inversion de noms :
- `ingredient.xlsx` contient les focaccias et leurs ingrédients
- `marque.xlsx` contient les ingrédients
- `focaccia.xlsx` contient les boissons et leurs marques

Les scripts ci-joints ont été préparés à partir du contenu réel de ces fichiers.
