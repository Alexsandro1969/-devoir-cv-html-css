-- =========================================================
-- Projet Tifosi - Script 3
-- Requêtes de vérification demandées dans le brief
-- Pour chaque requête :
--   - numéro et but
--   - code SQL
--   - résultat attendu
--   - résultat obtenu : à exécuter dans MySQL
--   - commentaire
-- =========================================================

USE tifosi;

-- =========================================================
-- Requête 1
-- But : afficher la liste des noms des focaccias par ordre alphabétique croissant
-- Résultat attendu :
-- Américaine
-- Emmentalaccia
-- Gorgonzollaccia
-- Hawaienne
-- Mozaccia
-- Paysanne
-- Raclaccia
-- Tradizione
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si le script d'insertion a bien été chargé
SELECT nom
FROM focaccia
ORDER BY nom ASC;

-- =========================================================
-- Requête 2
-- But : afficher le nombre total d'ingrédients
-- Résultat attendu :
-- 25
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si le script d'insertion a bien été chargé
SELECT COUNT(*) AS nombre_total_ingredients
FROM ingredient;

-- =========================================================
-- Requête 3
-- But : afficher le prix moyen des focaccias
-- Résultat attendu :
-- 10.38 (arrondi à 2 décimales)
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : la moyenne exacte est 10.375, affichée ici arrondie à 10.38
SELECT ROUND(AVG(prix), 2) AS prix_moyen_focaccias
FROM focaccia;

-- =========================================================
-- Requête 4
-- But : afficher la liste des boissons avec leur marque, triée par nom de boisson
-- Résultat attendu :
-- Capri-sun | Coca-cola
-- Coca-cola original | Coca-cola
-- Coca-cola zéro | Coca-cola
-- Eau de source | Cristalline
-- Fanta citron | Coca-cola
-- Fanta orange | Coca-cola
-- Lipton Peach | Pepsico
-- Lipton zéro citron | Pepsico
-- Monster energy ultra blue | Monster
-- Monster energy ultra gold | Monster
-- Pepsi | Pepsico
-- Pepsi Max Zéro | Pepsico
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si les boissons et les marques ont bien été chargées
SELECT b.nom AS boisson, m.nom AS marque
FROM boisson b
JOIN marque m
    ON m.id_marque = b.id_marque
ORDER BY b.nom ASC;

-- =========================================================
-- Requête 5
-- But : afficher la liste des ingrédients pour une Raclaccia
-- Résultat attendu :
-- Ail
-- Base Tomate
-- Champignon
-- Cresson
-- Parmesan
-- Poivre
-- Raclette
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si les relations focaccia/ingrédient ont bien été chargées
SELECT i.nom AS ingredient
FROM focaccia f
JOIN comprend c
    ON c.id_focaccia = f.id_focaccia
JOIN ingredient i
    ON i.id_ingredient = c.id_ingredient
WHERE f.nom = 'Raclaccia'
ORDER BY i.nom ASC;

-- =========================================================
-- Requête 6
-- But : afficher le nom et le nombre d'ingrédients pour chaque focaccia
-- Résultat attendu :
-- Américaine | 8
-- Emmentalaccia | 7
-- Gorgonzollaccia | 8
-- Hawaienne | 9
-- Mozaccia | 10
-- Paysanne | 12
-- Raclaccia | 7
-- Tradizione | 9
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si les données ont été intégrées correctement
SELECT f.nom, COUNT(*) AS nombre_ingredients
FROM focaccia f
JOIN comprend c
    ON c.id_focaccia = f.id_focaccia
GROUP BY f.id_focaccia, f.nom
ORDER BY f.nom ASC;

-- =========================================================
-- Requête 7
-- But : afficher le nom de la focaccia qui a le plus d'ingrédients
-- Résultat attendu :
-- Paysanne
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si les cardinalités sont correctes
SELECT f.nom
FROM focaccia f
JOIN comprend c
    ON c.id_focaccia = f.id_focaccia
GROUP BY f.id_focaccia, f.nom
ORDER BY COUNT(*) DESC, f.nom ASC
LIMIT 1;

-- =========================================================
-- Requête 8
-- But : afficher la liste des focaccias qui contiennent de l'ail
-- Résultat attendu :
-- Gorgonzollaccia
-- Mozaccia
-- Paysanne
-- Raclaccia
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si l'ingrédient Ail est correctement relié
SELECT DISTINCT f.nom
FROM focaccia f
JOIN comprend c
    ON c.id_focaccia = f.id_focaccia
JOIN ingredient i
    ON i.id_ingredient = c.id_ingredient
WHERE i.nom = 'Ail'
ORDER BY f.nom ASC;

-- =========================================================
-- Requête 9
-- But : afficher la liste des ingrédients inutilisés
-- Résultat attendu :
-- Salami
-- Tomate cerise
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si tous les ingrédients utilisés sont bien présents dans la table comprend
SELECT i.nom
FROM ingredient i
LEFT JOIN comprend c
    ON c.id_ingredient = i.id_ingredient
WHERE c.id_ingredient IS NULL
ORDER BY i.nom ASC;

-- =========================================================
-- Requête 10
-- But : afficher la liste des focaccias qui n'ont pas de champignons
-- Résultat attendu :
-- Américaine
-- Hawaienne
-- Résultat obtenu : exécuter la requête ci-dessous
-- Commentaire attendu : aucun écart si l'ingrédient Champignon est correctement renseigné
SELECT f.nom
FROM focaccia f
WHERE NOT EXISTS (
    SELECT 1
    FROM comprend c
    JOIN ingredient i
        ON i.id_ingredient = c.id_ingredient
    WHERE c.id_focaccia = f.id_focaccia
      AND i.nom = 'Champignon'
)
ORDER BY f.nom ASC;
